/*
 * ARM64 architecture-specific boot implementation - module implementation unit
 * Implements the unified boot interface for ARM64
 */

module;

// PSCI SMC64 CPU_ON function ID: 0xc4000003 selects the 64-bit affinity/entry
// call defined by PSCI, regardless of whether firmware uses SMC or HVC transport.
enum { PSCI_CPU_ON_64 = 0xC4000003 };

// Assembly-callable function forward declaration (defined in this file)
extern "C" [[noreturn]] void secondary_cpu_entry() noexcept;
extern "C" void arm64_secondary_start();
extern "C" unsigned long long boot_cpu_hardware_ids[16];

module moss.boot;

import moss.abi;
import moss.hal.uart;

// Bring assembly/linker symbols into scope via moss.abi
using moss::abi::_start;
using moss::abi::arm64::cpu_startup_flags;
using moss::abi::arm64::early_uart_lock;
using moss::abi::arm64::exception_vectors;

static void early_uart_lock_acquire() noexcept {
  unsigned int val, status;
  asm volatile("1:\n"
               "   ldxr  %w0, [%2]\n"
               "   cbnz  %w0, 1b\n"
               "   mov   %w0, #1\n"
               "   stxr  %w1, %w0, [%2]\n"
               "   cbnz  %w1, 1b\n"
               "   dmb   sy\n"
               : "=&r"(val), "=&r"(status)
               : "r"(&early_uart_lock)
               : "memory");
}

static void early_uart_lock_release() noexcept {
  asm volatile("dmb sy" ::: "memory");
  early_uart_lock = 0;
}

using moss::i32;
using moss::PhysAddr;
using moss::u16;
using moss::u32;
using moss::u64;
using moss::u8;
using moss::VirtAddr;

#if defined(MOSS_ARM64_PERF_PROBE)
// Diagnostic-only per-core counters: they include IRQs and other scheduled tasks.
// Production does not enable this access; no overflow interrupts or sampling hooks.
static void enable_performance_probe() noexcept {
  u64 pmcr, events;
  asm volatile("mrs %0, pmcr_el0; mrs %1, pmceid0_el0" : "=r"(pmcr), "=r"(events));
  // PMCR.N is bits [15:11]; the A53 provides six programmable event counters.
  constexpr u64 required_events = (1ULL << 0x03) | (1ULL << 0x08) | (1ULL << 0x11) | (1ULL << 0x17);
  if (((pmcr >> 11) & 0x1f) < 6 || (events & required_events) != required_events) {
    moss::kernel::arch::kernel_panic("performance probe requires six PMUv3 counters and A53 events");
  }
  // PMEVTYPER.P/U exclude EL1/EL0 respectively. Event IDs are ARM PMUv3's
  // INST_RETIRED=0x08, CPU_CYCLES=0x11, L1D_REFILL=0x03 and L2D_REFILL=0x17.
  constexpr u64 types[] = {
      (1ULL << 31) | 0x08, (1ULL << 30) | 0x08, (1ULL << 31) | 0x11, (1ULL << 30) | 0x11, 0x03, 0x17};
  constexpr u64 all_counters = 0xffffffffULL; // Clear every event enable/overflow bit, plus cycle bit 31.
  asm volatile("msr pmcr_el0, xzr; msr pmcntenclr_el0, %0; msr pmintenclr_el1, %0; "
               "msr pmovsclr_el0, %0; isb" ::"r"(all_counters)
               : "memory");
  for (u64 index = 0; index < sizeof(types) / sizeof(types[0]); ++index) {
    asm volatile("msr pmselr_el0, %0; isb; msr pmxevtyper_el0, %1" ::"r"(index), "r"(types[index]) : "memory");
  }
  // PMCCFILTR=0 counts both EL0/EL1. CR|ER grants reads only (not general EN).
  constexpr u64 read_access = (1ULL << 2) | (1ULL << 3);
  constexpr u64 enabled = (1ULL << 31) | 0x3f; // Cycle counter and event counters 0..5.
  // PMCR E|P|C|LC: enable, reset events/cycles, use the 64-bit cycle counter; no /64 divider.
  constexpr u64 control = (1ULL << 0) | (1ULL << 1) | (1ULL << 2) | (1ULL << 6);
  asm volatile("msr pmccfiltr_el0, xzr; msr pmuserenr_el0, %0; msr pmcntenset_el0, %1; "
               "msr pmcr_el0, %2; isb" ::"r"(read_access),
               "r"(enabled), "r"(control)
               : "memory");
  u64 timer_control;
  asm volatile("mrs %0, cntkctl_el1" : "=r"(timer_control));
  timer_control |= 1ULL << 1; // EL0VCTEN permits direct, low-overhead virtual timer reads.
  asm volatile("msr cntkctl_el1, %0; isb" ::"r"(timer_control) : "memory");
}
#endif

// Forward declaration
u32 get_current_cpu_id_impl() noexcept;

// ========================================================================
// SMP startup and CPU detection data structures
// ========================================================================

/// CPU startup control info - aligned with assembly memory layout
struct CpuStartupInfo {
  void (*entry_point)();
  volatile u32 startup_flag;
  u32 reserved;
  u64 stack_pointer;
  u32 cpu_id;
  u32 boot_status;
} __attribute__((packed, aligned(8)));

/// CPU online state enumeration
enum class CpuState : u32 { Offline = 0, Starting = 1, Parked = 2, Active = 3, Online = 4, Failed = 5 };

/// Global CPU topology info
/// All cross-CPU shared fields use __atomic builtins (not volatile) to ensure
/// correct memory ordering on ARM64.  We use raw builtins here because this
/// file runs before moss.containers is fully available.
struct CpuTopology {
  u32 total_cpus;                                   // written only by CPU 0 during init
  u32 online_cpus;                                  // atomic: concurrent inc from secondary CPUs
  u32 cpu_states[moss::kernel::BOOT_MAX_CPUS];      // atomic: each CPU writes its own slot; CPU 0 reads all
  u64 boot_timestamps[moss::kernel::BOOT_MAX_CPUS]; // written once per CPU during init
  bool detection_completed;                         // written by CPU 0, read by others after barrier
};

// Global variable definitions
static CpuTopology g_cpu_topology = {.total_cpus = 1,
                                     .online_cpus = 1,
                                     .cpu_states = {static_cast<u32>(CpuState::Online)},
                                     .boot_timestamps = {0},
                                     .detection_completed = false};

// ========================================================================
// Dynamic CPU detection and startup control functions
// ========================================================================

static u32 probe_available_cpus() noexcept {
  // Priority 1: Use DTB-derived CPU count (set during hardware_early_init)
  const auto &plat = moss::fdt::get_platform_info();
  if (plat.dtb_valid && plat.cpu_count > 0) {
    u32 count = plat.cpu_count;
    // Store the full count in g_num_cpus (runtime, unlimited)
    moss::kernel::g_num_cpus = count;
    // Boot arrays are limited to BOOT_MAX_CPUS
    if (count > moss::kernel::BOOT_MAX_CPUS) {
      count = moss::kernel::BOOT_MAX_CPUS;
    }
    return count;
  }

  return 0; // CPU topology must be provided by firmware.
}

static u64 get_timestamp() noexcept {
  u64 count;
  asm volatile("mrs %0, cntvct_el0" : "=r"(count));
  return count;
}

// Helpers for atomic cpu_states[] access (stored as u32, CpuState enum underneath)
static void store_cpu_state(u32 cpu_id, CpuState state) noexcept {
  __atomic_store_n(&g_cpu_topology.cpu_states[cpu_id], static_cast<u32>(state), __ATOMIC_RELEASE);
}

static CpuState load_cpu_state(u32 cpu_id) noexcept {
  return static_cast<CpuState>(__atomic_load_n(&g_cpu_topology.cpu_states[cpu_id], __ATOMIC_ACQUIRE));
}

static void initialize_cpu_startup_info(u32 detected_cpus) noexcept {
  g_cpu_topology.total_cpus = detected_cpus;
  __atomic_store_n(&g_cpu_topology.online_cpus, 1, __ATOMIC_RELAXED);
  g_cpu_topology.detection_completed = true;

  for (u32 cpu = 0; cpu < moss::kernel::BOOT_MAX_CPUS; cpu++) {
    if (cpu == 0) {
      store_cpu_state(cpu, CpuState::Online);
      g_cpu_topology.boot_timestamps[cpu] = get_timestamp();
    } else {
      store_cpu_state(cpu, CpuState::Offline);
      g_cpu_topology.boot_timestamps[cpu] = 0;
    }
  }

  for (u32 cpu = 0; cpu < moss::kernel::BOOT_MAX_CPUS; cpu++) {
    cpu_startup_flags[cpu][0] = 0;
    cpu_startup_flags[cpu][1] = 0;
  }
}

[[maybe_unused]] static bool wait_cpu_parked(u32 cpu_id, u32 timeout_ms) noexcept {
  if (cpu_id >= moss::kernel::BOOT_MAX_CPUS) {
    return false;
  }

  u32 iteration = 0;
  // Legacy polling policy: ten iterations per nominal ms, 10000 NOPs between
  // probes and diagnostics every 1000 probes. These are uncalibrated loop
  // counts, not a wall-clock guarantee; use wait_for_cpu_state for timed waits.
  // Numeric character 10 below is ASCII LF; cpu_id%10 prints its last digit only.
  u32 max_iterations = timeout_ms * 10;

  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('W');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc(static_cast<char>(10));
  early_uart_lock_release();

  while (load_cpu_state(cpu_id) != CpuState::Parked) {
    if (iteration >= max_iterations) {
      early_uart_lock_acquire();
      moss::kernel::hal::uart::putc('T');
      moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
      moss::kernel::hal::uart::putc(static_cast<char>(10));
      early_uart_lock_release();

      store_cpu_state(cpu_id, CpuState::Failed);
      return false;
    }

    for (volatile u32 i = 0; i < 10000; i = i + 1) {
      asm volatile("nop");
    }
    iteration++;

    if (iteration % 1000 == 0) {
      early_uart_lock_acquire();
      moss::kernel::hal::uart::putc('C');
      moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
      moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(load_cpu_state(cpu_id))));
      moss::kernel::hal::uart::putc(static_cast<char>(10));
      early_uart_lock_release();
    }
  }

  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('S');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc(static_cast<char>(10));
  early_uart_lock_release();

  return true;
}

void mark_cpu_online(u32 cpu_id) noexcept {
  if (cpu_id < moss::kernel::BOOT_MAX_CPUS) {
    store_cpu_state(cpu_id, CpuState::Online);
    g_cpu_topology.boot_timestamps[cpu_id] = 0;
    __atomic_fetch_add(&g_cpu_topology.online_cpus, 1, __ATOMIC_ACQ_REL);
  }
}

void mark_cpu_parked(u32 cpu_id) noexcept {
  if (cpu_id < moss::kernel::BOOT_MAX_CPUS) {
    g_cpu_topology.boot_timestamps[cpu_id] = 0;
    // Release store: makes all prior initialization visible to CPU 0
    store_cpu_state(cpu_id, CpuState::Parked);

    early_uart_lock_acquire();
    moss::kernel::hal::uart::putc('M');
    moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
    moss::kernel::hal::uart::putc(static_cast<char>(10));
    early_uart_lock_release();
  }
}

void mark_cpu_active(u32 cpu_id) noexcept {
  if (cpu_id < moss::kernel::BOOT_MAX_CPUS) {
    store_cpu_state(cpu_id, CpuState::Active);
  }
}

bool is_cpu_in_state(u32 cpu_id, CpuState expected_state) noexcept {
  if (cpu_id >= moss::kernel::BOOT_MAX_CPUS) {
    return false;
  }
  return load_cpu_state(cpu_id) == expected_state;
}

bool wait_for_cpu_state(u32 cpu_id, CpuState expected_state, u32 timeout_ms) noexcept {
  if (cpu_id >= moss::kernel::BOOT_MAX_CPUS) {
    return false;
  }

  const u64 start = get_timestamp();
  const u64 ticks = moss::kernel::hal::timer::frequency() / 1000 * timeout_ms;
  while (get_timestamp() - start < ticks) {
    if (load_cpu_state(cpu_id) == expected_state) {
      return true;
    }
    moss::kernel::arch::cpu_yield();
  }

  return load_cpu_state(cpu_id) == expected_state;
}

[[noreturn]] void cpu_park(u32 cpu_id) noexcept {

  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('P');
  moss::kernel::hal::uart::putc('A');
  moss::kernel::hal::uart::putc('R');
  moss::kernel::hal::uart::putc('K');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc(static_cast<char>(10));
  early_uart_lock_release();

  // Directly use store_cpu_state + UART (mark_cpu_parked does UART too,
  // but cpu_park has its own UART output above, so just set state here)
  store_cpu_state(cpu_id, CpuState::Parked);

  while (!is_cpu_in_state(cpu_id, CpuState::Active)) {
    asm volatile("wfi");

    // Uncalibrated 100-NOP backoff after wakeup; the specific count has no
    // recorded timing basis and does not turn WFI into a timed polling primitive.
    for (volatile u32 i = 0; i < 100; i = i + 1) {
      asm volatile("nop");
    }
  }

  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('A');
  moss::kernel::hal::uart::putc('C');
  moss::kernel::hal::uart::putc('T');
  moss::kernel::hal::uart::putc('V');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc(static_cast<char>(10));

  moss::kernel::hal::uart::putc('W');
  moss::kernel::hal::uart::putc('A');
  moss::kernel::hal::uart::putc('I');
  moss::kernel::hal::uart::putc('T');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc(static_cast<char>(10));
  early_uart_lock_release();

  while (true) {
    asm volatile("wfi");

    // Legacy terminal park loop: 1000 NOPs merely defer the next WFI;
    // its exact delay rationale is not recorded and it never resumes scheduling.
    for (u32 i = 0; i < 1000; i++) {
      asm volatile("nop");
    }
  }
}

// Secondary CPU entry point — park first, then full subsystem initialization
// on activation by CPU 0 (after GIC distributor and timer are ready).
extern "C" [[noreturn]] void secondary_cpu_entry() noexcept {
  // Firmware enters with the MMU off. Enable shared Normal-memory attributes
  // before UART locks or any atomic topology handshake: A53 rejects exclusive
  // accesses to the Device memory implied by SCTLR.M=0 (ESR=0x96000035).
  asm volatile("msr vbar_el1, %0; isb" ::"r"(exception_vectors) : "memory");
  using Tables = moss::kernel::mm::PageTableManager;
  auto *kernel_pgd = Tables::get_kernel_pgd();
  auto *high_pgd = Tables::get_kernel_high_pgd();
  if (!kernel_pgd || !high_pgd || !moss::kernel::hal::mmu::enable_mmu(Tables::get_physical_address(kernel_pgd))) {
    moss::kernel::arch::kernel_panic("secondary CPU MMU initialization failed");
  }
  moss::kernel::arch::setup_kernel_mmu(Tables::get_physical_address(high_pgd));

  // 1. Read CPU ID from hardware
  u32 cpu_id = moss::kernel::arch::get_current_cpu_id();

  // Minimal UART output (locked)
  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('S');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc('\n');
  early_uart_lock_release();

  // --- Phase 1: Park and wait for CPU 0 to finish initialization ---
  // Use atomic release store so CPU 0 sees the state transition
  if (cpu_id < moss::kernel::BOOT_MAX_CPUS) {
    store_cpu_state(cpu_id, CpuState::Parked);
  }

  // Poll until CPU 0 marks us Active. No timer or interrupt can rescue a
  // sleeping CPU at this phase, and QEMU 11.1.1 multi-threaded TCG has been
  // observed leaving a WFE host thread asleep after SEV publishes the state.
  // YIELD keeps the architectural state handshake while guaranteeing that
  // the secondary rechecks it; reconsider WFE only after every supported
  // platform provides a tested wake-up guarantee for this pre-IRQ phase.
  while (!is_cpu_in_state(cpu_id, CpuState::Active)) {
    moss::kernel::arch::cpu_yield();
  }

  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('I');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc('\n');
  early_uart_lock_release();

  // --- Phase 2: Full subsystem initialization (GIC/timer are ready) ---

  // 3. Enable FP/NEON access
  u64 cpacr = (3ULL << 20);
  asm volatile("msr cpacr_el1, %0" ::"r"(cpacr));
  asm volatile("isb");

  // 4. Initialize GIC CPU interface for this CPU
  // GICv3: init_cpu_interface() uses ICC system registers + GICR internally;
  //        the cpu_base argument is ignored (pass 0).
  // GICv2: init_cpu_interface() uses MMIO GICC registers via cpu_base.
  // BCM2836: the HAL initializes this physical core's local timer/mailbox controls.
  const auto &plat = moss::fdt::get_platform_info();
  moss::kernel::VirtAddr gic_cpu_base = 0;
  if (moss::kernel::hal::intc::g_gic_version != moss::kernel::hal::intc::GicVersion::GICv3) {
    gic_cpu_base = plat.intc.cpu_base;
  }
  (void)moss::kernel::hal::intc::init_cpu_interface(gic_cpu_base);

  // Enable the firmware timer source and reschedule IPI 0 on this CPU.
  // The HAL selects banked GIC registers, GICR or BCM2836's per-core controls.
  moss::kernel::VirtAddr gic_dist_base = plat.intc.dist_base;
  moss::kernel::hal::intc::enable_irq(gic_dist_base, moss::kernel::platform::timer_irq());
  moss::kernel::hal::intc::enable_irq(gic_dist_base, 0); // SGI 0 = Reschedule IPI

  // 5. Enable per-CPU timer and set initial compare for first tick.
  //    Use SCHED_LATENCY_NS (~6ms) so the first scheduler tick fires promptly.
  //    After that, irq_handler_c reprograms the compare register each tick.
  moss::kernel::hal::timer::enable();
  u64 counter_now = moss::kernel::hal::timer::read_counter();
  u64 first_tick_cycles = moss::kernel::timer::TimerSubsystem::instance().clocksource().ns_to_cycles(
      moss::kernel::process::cfs_params::SCHED_LATENCY_NS);
  moss::kernel::hal::timer::set_compare(counter_now + first_tick_cycles);

#if defined(MOSS_ARM64_PERF_PROBE)
  enable_performance_probe();
#endif

  // 6. Mark CPU as online (init complete)
  // mark_cpu_online uses __ATOMIC_RELEASE for state + __ATOMIC_ACQ_REL for count
  moss::boot::record_cpu_online();
  mark_cpu_online(cpu_id);
  asm volatile("sev" ::: "memory"); // wake CPU 0's wait_for_cpu_state

  early_uart_lock_acquire();
  moss::kernel::hal::uart::putc('R');
  moss::kernel::hal::uart::putc(static_cast<char>('0' + static_cast<u8>(cpu_id % 10)));
  moss::kernel::hal::uart::putc('\n');
  early_uart_lock_release();

  // 7. Enable IRQs and enter scheduling loop (never returns)
  asm volatile("msr daifclr, #2" ::: "memory");
  moss::kernel::process::secondary_cpu_schedule_loop(cpu_id);
}

// === Linux-style global GIC hardware instances ===

namespace moss::boot {

moss::kernel::interrupts::GenericInterruptController *g_gic_controller = nullptr;
bool g_gic_hardware_available = false;

} // namespace moss::boot

/// Activate parked secondary CPUs: mark Active (to unblock their init),
/// then wait for them to reach Online (init complete, scheduling loop entered).
namespace moss::boot {
void activate_secondary_cpus() noexcept {
  // Each Parked/Online wait gets 3000 ms. These are bounded activation-policy
  // timeouts, distinct from the 5000 ms CPU_ON park wait; tuning evidence for
  // the three-/five-second choices is not recorded.
  u32 successfully_activated = 0;

  for (u32 cpu_id = 1; cpu_id < g_cpu_topology.total_cpus; ++cpu_id) {
    // Wait for secondary CPU to reach Parked state (PSCI may take time)
    if (!wait_for_cpu_state(cpu_id, CpuState::Parked, 3000)) {
      continue;
    }

    // The release store pairs with the secondary's acquire polling. That CPU
    // cannot sleep in this pre-IRQ phase, so no separate event is required.
    mark_cpu_active(cpu_id);

    // Wait for it to finish init and reach Online state
    if (wait_for_cpu_state(cpu_id, CpuState::Online, 3000)) {
      successfully_activated++;
    }
  }

  __atomic_store_n(&g_cpu_topology.online_cpus, 1 + successfully_activated, __ATOMIC_RELAXED);
}

} // namespace moss::boot

// ARM64 PSCI call function
static u64 psci_call(u32 function_id, u64 arg0 = 0, u64 arg1 = 0, u64 arg2 = 0, u64 arg3 = 0) noexcept {
  register u64 x0 asm("x0") = function_id;
  register u64 x1 asm("x1") = arg0;
  register u64 x2 asm("x2") = arg1;
  register u64 x3 asm("x3") = arg2;
  register u64 x4 asm("x4") = arg3;
  if (moss::kernel::platform::hardware.psci_smc) {
    asm volatile("smc #0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x3), "r"(x4) : "memory");
  } else {
    asm volatile("hvc #0" : "+r"(x0) : "r"(x1), "r"(x2), "r"(x3), "r"(x4) : "memory");
  }
  return x0;
}

namespace moss::boot {

// Global boot status
BootStatus g_boot_status = {.current_stage = BootStage::PreInit,
                            .completed_stages_mask = 0,
                            .stage_timestamps = {0},
                            .last_error = ::moss::kernel::ErrorCode::Success};

// RAII guard — holds early_uart_lock for the lifetime of the scope.
// Use to group multiple early_print() calls into one atomic output block.
struct EarlyPrintGuard {
  EarlyPrintGuard() noexcept { early_uart_lock_acquire(); }
  ~EarlyPrintGuard() noexcept { early_uart_lock_release(); }
  EarlyPrintGuard(const EarlyPrintGuard &) = delete;
  auto operator=(const EarlyPrintGuard &) -> EarlyPrintGuard & = delete;
};

// Each HAL puts() takes its own TX lock. EarlyPrintGuard additionally groups
// multiple output calls with the separate boot lock when CPUs print concurrently.
static void early_print(const char *str) { moss::kernel::hal::uart::puts(str); }

static void early_print_hex(u64 value) {
  constexpr char hex_chars[] = "0123456789ABCDEF";
  char buffer[19] = "0x";

  for (int i = 15; i >= 0; i--) {
    buffer[2 + (15 - i)] = hex_chars[(value >> (i * 4)) & 0xF];
  }
  buffer[18] = '\0';

  early_print(buffer);
}

static u64 get_timestamp_counter() noexcept {
  u64 counter;
  asm volatile("mrs %0, cntvct_el0" : "=r"(counter));
  return counter;
}

u32 get_current_cpu_id_impl() noexcept { return moss::kernel::arch::get_current_cpu_id(); }

// Boot stage status update implementation
void update_boot_stage(BootStage stage, ::moss::kernel::ErrorCode error) noexcept {
  g_boot_status.current_stage = stage;
  g_boot_status.last_error = error;

  u32 stage_index = static_cast<u32>(stage);
  if (stage_index < 8) {
    g_boot_status.stage_timestamps[stage_index] = get_timestamp_counter();

    if (error == ::moss::kernel::ErrorCode::Success) {
      g_boot_status.completed_stages_mask |= (1U << stage_index);
    }
  }
}

} // namespace moss::boot

// ARM64BootImpl member function implementations
::moss::kernel::VoidResult moss::boot::ARM64BootImpl::hardware_early_init(BootContext &ctx) noexcept {
  moss::boot::update_boot_stage(moss::boot::BootStage::HardwareInit);

  early_print("=== ARM64 Hardware Early Init ===\n");

  ctx.cpu_id = moss::boot::get_current_cpu_id_impl();
  early_print("CPU ID: ");
  early_print_hex(ctx.cpu_id);
  early_print("\n");

  if (!moss::fdt::parse_dtb(ctx.device_tree_ptr)) {
    return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::InvalidArgument};
  }
  const auto &info = moss::fdt::get_platform_info();
  if (!info.memory_map_valid || !info.intc.valid || !info.cpu_count || info.cpu_count > 16 || !info.timer_interrupt) {
    return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::InvalidArgument};
  }
  u64 boot_id;
  asm volatile("mrs %0, mpidr_el1" : "=r"(boot_id));
  if (!moss::kernel::platform::order_cpus(boot_id & 0xFF00FFFFFFULL)) {
    return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::InvalidArgument};
  }
  for (u32 i = 0; i < info.cpu_count; ++i) {
    // ICC_SGI1R range selection (Aff0 >= 16) is not implemented yet.
    if ((info.intc.gic_version == 3 && (info.cpus[i].hardware_id & 0xFF) >= 16) ||
        (i && info.cpus[i].enable_method == moss::kernel::platform::CpuEnableMethod::Psci && !info.psci_valid)) {
      return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::InvalidArgument};
    }
    boot_cpu_hardware_ids[i] = info.cpus[i].hardware_id;
    asm volatile("dc cvac, %0" ::"r"(&boot_cpu_hardware_ids[i]) : "memory");
  }
  asm volatile("dsb sy" ::: "memory");
  ctx.memory_start = info.total_memory_start;
  ctx.memory_size = info.total_memory_size;
  ctx.kernel_phys_base = reinterpret_cast<PhysAddr>(moss::abi::_start);
  ctx.total_cpus = info.cpu_count;
  early_print("DTB hardware discovered\n");

  ctx.kernel_virt_base = moss::boot::arch_constants::KERNEL_VIRT_BASE;

  early_print("ARM64 hardware init complete\n\n");
  return ::moss::kernel::VoidResult{};
}

::moss::kernel::VoidResult moss::boot::ARM64BootImpl::setup_memory_management(BootContext &ctx) noexcept {
  (void)ctx;
  moss::boot::update_boot_stage(moss::boot::BootStage::MemoryManagement);

  early_print("=== ARM64 Memory Management Setup ===\n");

  // Phase 1: Setup permission-separated identity mappings in TTBR0.
  auto mmu_result = ::moss::kernel::mm::setup_mmu();
  if (!mmu_result) {
    early_print("MMU setup failed\n");
    return ::moss::kernel::VoidResult{mmu_result.error()};
  }

  // Phase 2: Initialize PageFrameAllocator (buddy allocator)
  auto pfa_result = ::moss::kernel::mm::PageFrameAllocator::initialize();
  if (!pfa_result) {
    early_print("Physical page allocator init failed\n");
    return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::OutOfMemory};
  }

  // Phase 3: Build TTBR1 high-half kernel page table
  // Maps physical 0-4GB at KERNEL_DIRECT_MAP_BASE (0xFFFF800000000000)
  early_print("Building TTBR1 high-half kernel page table...\n");
  auto high_result = ::moss::kernel::mm::PageTableManager::setup_kernel_high_half_tables();
  if (!high_result) {
    early_print("High-half page table setup failed\n");
    return ::moss::kernel::VoidResult{high_result.error()};
  }

  // Phase 4: Activate TTBR1 — write high-half PGD to ttbr1_el1
  PhysAddr high_pgd_pa = ::moss::kernel::mm::PageTableManager::get_physical_address(
      ::moss::kernel::mm::PageTableManager::get_kernel_high_pgd());

  early_print("TTBR1 PGD physical: ");
  early_print_hex(high_pgd_pa);
  early_print("\n");

#if defined(MOSS_ARCH_ARM64)
  // Write TTBR1 with kernel high-half PGD (ASID=0 for kernel)
  asm volatile("msr ttbr1_el1, %0" ::"r"(high_pgd_pa));
  asm volatile("isb" ::: "memory");

  // Full TLB invalidation to ensure new TTBR1 mappings take effect
  asm volatile("tlbi vmalle1" ::: "memory");
  asm volatile("dsb sy" ::: "memory");
  asm volatile("isb" ::: "memory");
#endif

  early_print("TTBR1 high-half mapping active\n");

  // Phase 5: Enable dynamic page table allocation (buddy-backed)
  ::moss::kernel::mm::PageTableManager::enable_dynamic_alloc();

  // Phase 6: Initialize runtime heap
  VirtAddr heap_start = moss::abi::linker::heap_start();
  // Start with 256 KiB inside the linker-reserved 8 MiB heap. This is an initial
  // allocator policy, not all firmware RAM; exact sizing evidence is not recorded.
  ::moss::kernel::usize initial_heap_size = 256ULL * 1024;
  auto heap_result = ::moss::kernel::mm::RuntimeHeapAllocator::initialize_heap(heap_start, initial_heap_size);
  if (!heap_result) {
    early_print("Runtime heap allocator init failed\n");
    return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::OutOfMemory};
  }

  early_print("ARM64 memory management setup complete (high-half active)\n\n");
  return ::moss::kernel::VoidResult{};
}

::moss::kernel::VoidResult moss::boot::ARM64BootImpl::setup_interrupts_and_exceptions(BootContext &ctx) noexcept {
  (void)ctx;
  moss::boot::update_boot_stage(moss::boot::BootStage::InterruptsExceptions);

  early_print("=== ARM64 Interrupts and Exceptions Setup ===\n");

  using namespace moss::kernel::interrupts;
  g_gic_controller = new GenericInterruptController();
  if (!g_gic_controller) {
    return ::moss::kernel::VoidResult{::moss::kernel::ErrorCode::OutOfMemory};
  }
  const auto &intc = moss::kernel::platform::hardware.intc;
  auto result = g_gic_controller->initialize(intc.dist_base, intc.gic_version >= 3 ? intc.redist_base : intc.cpu_base,
                                             intc.gic_version);
  if (!result) {
    delete g_gic_controller;
    g_gic_controller = nullptr;
    return result;
  }
  g_gic_hardware_available = true;

  // Reschedule IPI 0 must also be enabled on the BSP. Initialization clears
  // BCM2836's per-core mailbox mask; AP startup already enables this source.
  // Without it, remote wakeups on CPU0 wait until the next scheduler tick.
  moss::kernel::hal::intc::enable_irq(intc.dist_base, 0);

#if defined(MOSS_ARM64_PERF_PROBE)
  enable_performance_probe();
  early_print("RPI_PMU enabled: EL0/EL1 instructions/cycles, L1D/L2D refills\n");
#endif

  early_print("ARM64 interrupt/exception setup complete\n\n");
  return ::moss::kernel::VoidResult{};
}

::moss::kernel::VoidResult moss::boot::ARM64BootImpl::setup_smp_support(BootContext &ctx) noexcept {
  moss::boot::update_boot_stage(moss::boot::BootStage::SmpSupport);

  {
    EarlyPrintGuard g;
    early_print("=== ARM64 SMP Support Setup (Dynamic Detection) ===\n");
  }

  u32 detected_cpus = probe_available_cpus();
  {
    EarlyPrintGuard g;
    early_print("Detected CPU count: ");
    early_print_hex(static_cast<u64>(detected_cpus));
    early_print("\n");
  }

  initialize_cpu_startup_info(detected_cpus);

  if (detected_cpus == 1) {
    {
      EarlyPrintGuard g;
      early_print("Single-core mode\n");
    }
    ctx.total_cpus = 1;
  } else {
    {
      EarlyPrintGuard g;
      early_print("Multi-core boot sequence:\n");
    }

    u32 successful_cpus = 1;

    for (u32 cpu_id = 1; cpu_id < detected_cpus; cpu_id++) {
      {
        EarlyPrintGuard g;
        early_print("   Starting CPU ");
        early_print_hex(static_cast<u64>(cpu_id));
        early_print(" via firmware enable-method...\n");
      }

      // Mark Starting BEFORE PSCI call to avoid race: secondary CPU
      // may reach Parked before we return from PSCI, and we must not
      // overwrite its Parked state with Starting.
      store_cpu_state(cpu_id, CpuState::Starting);

      cpu_startup_flags[cpu_id][0] = reinterpret_cast<u64>(secondary_cpu_entry);
      cpu_startup_flags[cpu_id][1] = 1;

      asm volatile("dmb sy" ::: "memory");
      asm volatile("dsb sy" ::: "memory");

      asm volatile("dc civac, %0" : : "r"(&cpu_startup_flags[cpu_id][0]) : "memory");
      asm volatile("dc civac, %0" : : "r"(&cpu_startup_flags[cpu_id][1]) : "memory");
      asm volatile("dsb sy" ::: "memory");

      asm volatile("sev" ::: "memory");

      const auto &cpu = moss::kernel::platform::hardware.cpus[cpu_id];
      u64 target_mpidr = cpu.hardware_id;
      u64 entry_addr = reinterpret_cast<u64>(arm64_secondary_start);
      u64 context_id = static_cast<u64>(cpu_id);

      {
        EarlyPrintGuard g;
        early_print("   CPU start: target=");
        early_print_hex(target_mpidr);
        early_print(" entry=");
        early_print_hex(entry_addr);
        early_print("\n");
      }

      u64 psci_result = ~0ULL;
      if (cpu.enable_method == moss::kernel::platform::CpuEnableMethod::Psci) {
        psci_result = psci_call(PSCI_CPU_ON_64, target_mpidr, entry_addr, context_id);
      } else if (cpu.enable_method == moss::kernel::platform::CpuEnableMethod::SpinTable && cpu.release_address &&
                 !(cpu.release_address & 7) && cpu.release_address < 0x100000000ULL) {
        // Spin-table release cells are 8-byte addresses; this boot profile only
        // accesses physical cells below its supported 4 GiB identity-map limit.
        auto *release = reinterpret_cast<volatile u64 *>(cpu.release_address);
        *release = entry_addr;
        asm volatile("dc cvac, %0; dsb sy; sev" ::"r"(release) : "memory");
        psci_result = 0;
      }

      {
        EarlyPrintGuard g;
        early_print("   CPU start result: ");
        early_print_hex(psci_result);
        early_print(psci_result == 0 ? " (success)\n" : " (failed)\n");
      }

      if (psci_result != 0) {
        continue;
      }

      // Wait for this CPU to reach Parked before starting the next.
      // Serializes boot so each CPU's debug output ([N], CPUN:S, DN, SN)
      // appears cleanly between its own PSCI result and the next CPU.
      if (!wait_for_cpu_state(cpu_id, CpuState::Parked, 5000)) {
        {
          EarlyPrintGuard g;
          early_print("   Warning: CPU ");
          early_print_hex(static_cast<u64>(cpu_id));
          early_print(" did not park in time\n");
        }
      }
    }

    // Count successfully parked CPUs
    successful_cpus = 1;
    for (u32 cpu_id = 1; cpu_id < detected_cpus; cpu_id++) {
      if (load_cpu_state(cpu_id) == CpuState::Parked) {
        successful_cpus++;
      }
    }
    ctx.total_cpus = successful_cpus;

    if (successful_cpus > 1) {
      {
        EarlyPrintGuard g;
        early_print("SMP boot complete: ");
        early_print_hex(static_cast<u64>(successful_cpus));
        early_print(" CPUs online\n");
      }
    } else {
      {
        EarlyPrintGuard g;
        early_print("Secondary CPU startup failed, fallback to single-core mode\n");
      }
      ctx.total_cpus = 1;
    }
  }

  return ::moss::kernel::VoidResult{};
}

::moss::kernel::VoidResult moss::boot::ARM64BootImpl::finalize_arch_init(BootContext & /* ctx */) noexcept {
  {
    EarlyPrintGuard g;
    early_print("=== ARM64 Architecture Init Complete ===\n");
  }

  // Mark runtime heap as ready so operator new uses RuntimeHeapAllocator
  // instead of the 64KB early static buffer
  moss::abi::entry::mark_runtime_heap_ready();
  {
    EarlyPrintGuard g;
    early_print("Runtime heap marked ready\n");
  }

  {
    EarlyPrintGuard g;
    early_print("ARM64 architecture-specific init all complete\n\n");
  }
  return ::moss::kernel::VoidResult{};
}

::moss::kernel::VoidResult moss::boot::ARM64BootImpl::detect_memory_layout(BootContext &ctx) noexcept {
  (void)ctx;
  return ::moss::kernel::VoidResult{};
}

u32 moss::boot::ARM64BootImpl::get_current_cpu_id() noexcept { return moss::boot::get_current_cpu_id_impl(); }

[[noreturn]] void moss::boot::ARM64BootImpl::arch_panic(const char *message) noexcept {
  early_print("\n=== ARM64 PANIC ===\n");
  early_print(message);
  early_print("\n==================\n");

  // Compose PSCI SYSTEM_OFF ID 0x84000008 from its two 16-bit halves. This
  // legacy path uses SMC directly; HVC-only firmware needs separate handling.
  asm volatile("movz x0, #0x0008, lsl #0\n"
               "movk x0, #0x8400, lsl #16\n"
               "smc #0\n"
               :
               :
               : "x0");

  while (true) {
    asm volatile("wfi");
  }
}
