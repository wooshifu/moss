from pathlib import Path
import hashlib,json,shutil,sys,tempfile,time
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from scripts import rpi
base=Path(__file__).resolve().parent/'candidate-pinned'; output=base/'deploy'
result=output/'result.json';shutil.copyfile(result,output/'failed-readback-result.json')
record=json.loads(result.read_text()); source=base/'initramfs.cpio';readback=base/'initramfs.cpio.readback'
data=source.read_bytes();prefix=readback.read_bytes()
# The failed dump was at 0x20580000; subtract the 0x20000000 initrd base.
assert prefix==data[:len(prefix)] and len(prefix)==0x580000
with rpi.uart(rpi.serial_port(None)) as fd, rpi.OpenOCD() as o:
    o.command('targets bcm2837.cpu0');o.command('adapter speed 1000')
    assert o.command('bcm2837.cpu0 curstate')=='halted'
    # cache_off is 0x1000c0 in this deployment's handoff.elf; refuse an unexpected PC.
    assert '0x00000000001000c0' in o.command('reg pc')
    with tempfile.TemporaryDirectory(prefix='moss-rpi-recovery-') as folder, readback.open('ab') as dst:
        block=Path(folder)/'block.bin';started=time.monotonic()
        for offset in range(len(prefix),len(data),rpi.TRANSFER_CHUNK):
            size=min(rpi.TRANSFER_CHUNK,len(data)-offset)
            o.command(f'dump_image {rpi.tcl_path(block)} {rpi.INITRD_BASE+offset:#x} {size}')
            received=block.read_bytes();assert len(received)==size
            dst.write(received);dst.flush()
            rpi.transfer_progress('Recovery readback initramfs',offset+size,len(data),started)
    assert readback.read_bytes()==data
    print('Verified complete initramfs SHA256',hashlib.sha256(data).hexdigest(),flush=True)
    o.load(output/'moss.dtb',rpi.DTB_BASE)
    for name,value in [('x0',rpi.DTB_BASE),('x1',0),('x2',0),('x3',0)]:o.command(f'reg {name} {value:#x}')
    record['recovery']={'reason':'Invalid ACK (7) at 2 MHz during readback; kernel not yet executed','verified_prefix_bytes':len(prefix),'remaining_readback_khz':1000,'initramfs_complete_sha256':hashlib.sha256(data).hexdigest()}
    o.command(f'resume {rpi.IMAGE_BASE:#x}')
    try:
        rpi.console(fd,output/'serial.log',timeout=90,send=None,expect=None,check=True)
        record['boot_check']='shell_input_passed'
    except Exception as error:
        record['boot_check']='failed';record['error']=str(error);raise
    finally:result.write_text(json.dumps(record,indent=2)+'\n')
