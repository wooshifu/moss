#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = []
# ///
"""Prepare and measure the production Pi userspace probe; deploy its manifest with rpi.py first."""

import argparse
import hashlib
import json
import os
import select
import shutil
import statistics
import sys
import time
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.artifacts import Artifacts
from scripts.gen_initramfs import align4, make_cpio_entry, make_cpio_trailer
from scripts.rpi import run, serial_port, tool, uart, write_all

ROOT = Path(__file__).resolve().parents[1]
# Exploratory batches: cheap calls need more iterations; fork/exec and page
# faults are deliberately bounded to keep the real board responsive.
CASES = [
    ("clock", 20000, 1),
    ("getpid_raw", 20000, 1),
    ("getpid_libc", 1000, 1),
    ("yield", 1000, 1),
    ("memcpy", 256, 1024 * 1024),
    ("open_close", 1000, 1),
    ("read_seek", 4096, 64),
    ("read_seek", 4096, 512),
    ("read_seek", 1024, 4096),
    ("read_seek", 64, 65536),
    ("write_seek", 1024, 4096),
    ("fault", 8, 1024 * 1024),
    ("fork_raw", 8, 1),
    ("fork_libc", 8, 1),
    ("exec", 8, 1),
    ("ipc0", 1000, 1),
    ("ipc0_deadline", 1000, 1),
    ("ipc1", 1000, 1),
    ("ipc1_deadline", 1000, 1),
]


def prepare(manifest: Path, output: Path):
    artifacts = Artifacts.load(manifest)
    if artifacts.arch != "ARM64" or artifacts.build["type"] != "Release":
        raise ValueError("Use the ARM64 Release manifest")
    output.mkdir(parents=True, exist_ok=True)
    runtime = artifacts.manifest.parent / "src/userspace/mlibc"
    binary = output / "rpi-perf.elf"
    run(
        tool("clang"),
        "--target=aarch64-unknown-elf",
        "-mno-outline-atomics",
        "-O2",
        "-ffreestanding",
        "-fno-stack-protector",
        "-Wall",
        "-Wextra",
        "-Werror",
        f"-I{ROOT / 'src/userspace'}",
        f"-I{ROOT / 'src/abi/include'}",
        "-isystem",
        str(runtime / "sysroot/usr/include"),
        "-nostdlib",
        "-static",
        "-fuse-ld=lld",
        # Match production runtime programs: link above inherited identity maps, on 4 KiB pages.
        "-Wl,--image-base=0x200000000,-z,max-page-size=4096",
        str(ROOT / "scripts/rpi_perf.c"),
        str(runtime / "mlibc/CMakeFiles/mlibc-crt1.dir/sysdeps/moss/crt1.S.obj"),
        str(runtime / "sysroot/usr/lib/libc.a"),
        str(runtime / "builtins/lib/generic/libclang_rt.builtins-aarch64.a"),
        "-o",
        str(binary),
    )
    run(tool("llvm-strip"), "--strip-all", str(binary))
    archive = artifacts.require("initramfs").read_bytes()
    position, last_ino = 0, 0
    while True:
        if archive[position : position + 6] != b"070701":
            raise ValueError("Expected a newc production initramfs")
        # newc's 110-byte header is a six-byte magic plus thirteen eight-digit hex fields.
        fields = [int(archive[position + 6 + i * 8 : position + 14 + i * 8], 16) for i in range(13)]
        ino, size, namesize = fields[0], fields[6], fields[11]
        name = archive[position + 110 : position + 110 + namesize - 1]
        if name == b"TRAILER!!!":
            break
        last_ino = max(last_ino, ino)
        position = align4(align4(position + 110 + namesize) + size)
    (output / "initramfs.cpio").write_bytes(
        archive[:position] + make_cpio_entry(binary.name, binary.read_bytes(), ino=last_ino + 1) + make_cpio_trailer()
    )
    data = json.loads(artifacts.manifest.read_text())
    for key in ("kernel", "debug_symbols"):
        source = artifacts.require(key)
        shutil.copyfile(source, output / source.name)
        data["artifacts"][key] = source.name
    data["artifacts"]["initramfs"] = "initramfs.cpio"
    for key in ("validation_kernel", "validation_initramfs", "validation_debug_symbols"):
        data["artifacts"][key] = None
    (output / "moss-artifacts.json").write_text(json.dumps(data, indent=2) + "\n")
    print(f"Prepared {output / 'moss-artifacts.json'}; deploy it using rpi.py deploy --check")


def measure(port: str | None, output: Path, selected: list[str] | None):
    output.mkdir(parents=True, exist_ok=True)
    cases = [case for case in CASES if selected is None or case[0] in selected]
    if not cases or (selected and set(selected) - {case[0] for case in cases}):
        raise ValueError("Unknown workload")
    device = serial_port(port)
    report = {
        "port": device,
        "probe_sha256": hashlib.sha256((output / "rpi-perf.elf").read_bytes()).hexdigest(),
        "probe_source_sha256": hashlib.sha256((ROOT / "scripts/rpi_perf.c").read_bytes()).hexdigest(),
        "cases": [],
        "status": "running",
    }
    deployment = output / "deploy/result.json"
    if deployment.is_file():
        report["deployment_record"] = json.loads(deployment.read_text())
    result = output / f"measurements-{time.time_ns()}.json"
    try:
        with uart(device) as fd, result.with_suffix(".log").open("ab", buffering=0) as log:
            for name, iterations, size in cases:
                command = f"/rpi-perf.elf {name} {iterations} {size}; echo RPI_COMMAND_STATUS=$?\n"
                write_all(fd, command.encode())
                data = bytearray()
                # Three minutes bounds unusually slow service/fork cases; this is a host
                # liveness deadline, never a guest latency or regression threshold.
                deadline = time.monotonic() + 180
                while b"\nRPI_COMMAND_STATUS=" not in data.replace(b"\r\n", b"\n") or not data.endswith(b"moss$ "):
                    if time.monotonic() >= deadline:
                        raise TimeoutError(f"Timed out: {name}/{size}")
                    # One-second polls enforce the host deadline without busy waiting.
                    if select.select([fd], [], [], 1)[0]:
                        # Match the console's existing 4 KiB read buffer.
                        block = os.read(fd, 4096)
                        if not block:
                            raise ConnectionError("Serial adapter disconnected")
                        log.write(block)
                        data.extend(block)
                lines = data.decode(errors="replace").replace("\r\n", "\n").splitlines()
                rows = [json.loads(line.removeprefix("RPI_PERF ")) for line in lines if line.startswith("RPI_PERF {")]
                # Require the full protocol and child exit status; echoed commands cannot pass.
                if (
                    "RPI_COMMAND_STATUS=0" not in lines
                    or "RPI_PERF_DONE" not in lines
                    or any("RPI_PERF_ERROR" in line for line in lines)
                ):
                    raise RuntimeError(data.decode(errors="replace"))
                retained = [row for row in rows if not row["warmup"]]
                # Match the guest's two warmups and seven retained batches.
                if (
                    len(rows) != 9
                    or len(retained) != 7
                    or any(
                        row["ns"] <= 0
                        or row["sample"] != index
                        or row["warmup"] != (index < 2)
                        or row["iterations"] != iterations
                        or row["bytes"] != size
                        or row["workload"] != name
                        for index, row in enumerate(rows)
                    )
                ):
                    raise ValueError("Incomplete or invalid probe samples")
                values = [row["ns"] / iterations for row in retained]
                item = {
                    "workload": name,
                    "bytes": size,
                    "median_ns": statistics.median(values),
                    "min_ns": min(values),
                    "max_ns": max(values),
                    "samples": rows,
                }
                report["cases"].append(item)
                print(f"{name:18} bytes={size:7} median={item['median_ns'] / 1000:10.3f} us/op", flush=True)
                result.write_text(json.dumps(report, indent=2) + "\n")
        report["status"] = "passed"
    except Exception as error:
        report["status"], report["error"] = "failed", str(error)
        raise
    finally:
        result.write_text(json.dumps(report, indent=2) + "\n")
        print(f"Results: {result}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "measure"))
    parser.add_argument("--manifest", type=Path, default=Path("build/arm64-release/moss-artifacts.json"))
    parser.add_argument("--output", type=Path, default=Path("build/rpi3b/perf"))
    parser.add_argument("--port")
    parser.add_argument("--workload", action="append", help="Measure only this workload; repeat to select more")
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare(args.manifest, args.output)
    else:
        measure(args.port, args.output, args.workload)


if __name__ == "__main__":
    main()
