"""Drive the measurement collector through a real PTY, including failed guest runs."""

import json
import os
import pty
import select
import threading

import pytest

from scripts import rpi_perf


@pytest.mark.parametrize("failure", [None, "missing_sample", "duplicate_sample", "wrong_warmup", "guest_error"])
def test_measure_requires_complete_guest_results_and_success(tmp_path, monkeypatch, failure):
    master, slave = pty.openpty()
    monkeypatch.setattr(rpi_perf, "CASES", [("clock", 2, 1)])
    (tmp_path / "rpi-perf.elf").write_bytes(b"test probe identity")
    rows = [
        {"workload": "clock", "sample": i, "warmup": i < 2, "iterations": 2, "bytes": 1, "ns": 100, "switches": 0}
        for i in range(9)
    ]
    if failure == "missing_sample":
        rows.pop()
    elif failure == "duplicate_sample":
        rows[-1]["sample"] = rows[-2]["sample"]
    elif failure == "wrong_warmup":
        rows[0]["warmup"], rows[2]["warmup"] = False, True
    response = "\r\n" + "\r\n".join("RPI_PERF " + json.dumps(row) for row in rows)
    response += "\r\nRPI_PERF_DONE\r\nRPI_COMMAND_STATUS=" + ("1" if failure == "guest_error" else "0") + "\r\nmoss$ "
    sent = []

    def board():
        # Three seconds bounds a collector that failed to open/transmit to the PTY.
        if select.select([master], [], [], 3)[0]:
            sent.append(os.read(master, 4096))
            os.write(master, response.encode())

    thread = threading.Thread(target=board, daemon=True)
    thread.start()
    try:
        if failure:
            with pytest.raises((RuntimeError, ValueError)):
                rpi_perf.measure(os.ttyname(slave), tmp_path, None)
        else:
            rpi_perf.measure(os.ttyname(slave), tmp_path, None)
        thread.join(timeout=3)
        assert not thread.is_alive()
        assert sent == [b"/rpi-perf.elf clock 2 1; echo RPI_COMMAND_STATUS=$?\n"]
        result = json.loads(next(tmp_path.glob("measurements-*.json")).read_text())
        assert result["status"] == ("failed" if failure else "passed")
        assert next(tmp_path.glob("measurements-*.log")).read_bytes() == response.encode()
        if not failure:
            assert result["cases"][0]["median_ns"] == 50
            assert len(result["cases"][0]["samples"]) == 9
    finally:
        os.close(master)
        os.close(slave)
