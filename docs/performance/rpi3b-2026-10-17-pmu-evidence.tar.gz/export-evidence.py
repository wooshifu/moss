"""Package the completed experiment without committing generated kernel binaries."""

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
destination = root.parents[2] / "docs/performance"
destination.mkdir(exist_ok=True)


def read(relative):
    return json.loads((root / relative).read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


runs = []
for path in sorted(root.glob("*/measurements-*.json"), key=lambda item: item.name):
    report = json.loads(path.read_text())
    cases = []
    for case in report["cases"]:
        diagnostic = case.get("diagnostic", {})
        retained = case["samples"][2:]  # Guest protocol has exactly two warmup batches.
        cases.append({
            "workload": case["workload"],
            "bytes": case["bytes"],
            "batch_median_ns": case["median_ns"],
            "count": diagnostic.get("count"),
            "individual_tail_ns": diagnostic.get("tail_ns"),
            "cpu0_counters_per_op": diagnostic.get("counters_per_op"),
            "system_switches_per_op": sum(row["switches"] for row in retained)
            / sum(row["iterations"] for row in retained),
            "temperature_before": case.get("temperature_before"),
            "temperature_after": case.get("temperature_after"),
        })
    runs.append({
        "record": str(path.relative_to(root)),
        "status": report["status"],
        "error": report.get("error"),
        "service_affinity_cpu": report.get("preparation", {}).get("service_affinity_cpu"),
        "collector_sha256": report.get("collector_sha256"),
        "probe_sha256": report["probe_sha256"],
        "probe_source_sha256": report["probe_source_sha256"],
        "cases": cases,
    })

validation = read("validation/deploy/validation-result.json")
production = read("production/deploy/result.json")
assert validation["status"] == "passed"
assert production["boot_check"] == "shell_input_passed"
controlled = [run for run in runs if run["service_affinity_cpu"] == 2]
assert all(run["status"] == "passed" for run in controlled)
assert len({run["probe_sha256"] for run in controlled}) == 1
assert any(run["record"].startswith("baseline-crossback/") for run in controlled)

# Preserve binary identities; the archive contains source, raw samples and logs.
binaries = [
    {"path": str(path.relative_to(root)), "bytes": path.stat().st_size, "sha256": digest(path)}
    for path in sorted(root.rglob("*"))
    if path.is_file() and path.suffix in {".bin", ".elf", ".cpio", ".dtb", ".readback"}
]
write(root / "binary-inventory.json", binaries)

archive = destination / "rpi3b-2026-10-17-pmu-evidence.tar.gz"
included = []
text_types = {".json", ".log", ".patch", ".txt", ".c", ".cpp", ".py", ".h", ".dtsi", ".md", ".xml", ".gdb", ".dtb", ".S"}
# Stable gzip/tar metadata makes the artifact reproducible from the same inputs.
with archive.open("wb") as output, gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed:
    with tarfile.open(mode="w", fileobj=compressed) as bundle:
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix not in text_types:
                continue
            data = path.read_bytes()
            name = str(path.relative_to(root))
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            bundle.addfile(info, io.BytesIO(data))
            included.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

# Check the bytes actually packaged, including failure records and raw ticks.
with tarfile.open(archive, "r:gz") as bundle:
    assert bundle.getnames() == [entry["path"] for entry in included]
    for entry in included:
        assert hashlib.sha256(bundle.extractfile(entry["path"]).read()).hexdigest() == entry["sha256"]

summary = {
    "schema_version": 1,
    "date": "2026-10-17",
    "hardware": "Raspberry Pi 3B+ / BCM2837 / Cortex-A53; J-Link 50120677",
    "source_base": read("candidate/source-provenance.json")["head"],
    "build": "ARM64 Release; isolated worktree; excludes concurrent main-worktree features",
    "method": "CPU0 probe; IPC peer CPU0/1; controlled services CPU2; temperature CPU3; two warmups and seven retained batches; nearest-rank individual tails",
    "limits": [
        "CPU0-wide PMU counts include other tasks and IRQs; exclude CPU1/2 work and include read overhead",
        "Pinned diagnostic service layout is not production scheduling policy",
        "No statistical confidence bound or universal improvement claim; slower IPC observations retained, version attribution unresolved",
        "Thermal stress is bounded single-core work, with debugger sampling; no four-core long-duration validation",
        "No firmware clock/throttling-flag readings and no x64/RISC-V validation",
    ],
    "runs": runs,
    "thermal": read("thermal-stress-1792167974027072000.json"),
    "hardware_validation": validation,
    "final_production_deployment": production,
    "final_hardware_state": read("production/deploy/final-state.json"),
    "host_validation": read("host-validation.json"),
    "supplementary_qemu": {
        "suites": [{"workload": guest["workload"], "status": guest["status"], "cases": len(guest["cases"])}
                   for guest in read("candidate-normal-tests/results.json")["guests"]],
        "production": {key: read("production-check/results.json")[key]
                       for key in ("status", "completed_steps", "elapsed_seconds")},
    },
    "evidence_archive": {"path": archive.name, "sha256": digest(archive), "files": included},
}
write(destination / "rpi3b-2026-10-17-pmu.json", summary)
print(f"Packaged {len(included)} files; {archive.stat().st_size} compressed bytes")
