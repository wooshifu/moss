from argparse import Namespace
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from scripts import rpi
original = rpi.OpenOCD.command
def slow(self, command):
    return original(self, 'adapter speed 2000' if command == 'adapter speed 4000' else command)
rpi.OpenOCD.command = slow
rpi.deploy(Namespace(output=Path(sys.argv[2]), manifest=Path(sys.argv[1]), dtb=Path('build/rpi3b/firmware.dtb'), port=None, check=True, timeout=90))
