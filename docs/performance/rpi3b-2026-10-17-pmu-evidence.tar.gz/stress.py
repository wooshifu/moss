"""Bounded, UART-driven copy stress; JTAG temperature halts on CPU3 invalidate timing benchmarks."""
import json, os, select, sys, time
from pathlib import Path
sys.path.insert(0, '/private/tmp/moss-performance-20261016')
from scripts.rpi import uart, serial_port, write_all
from scripts.rpi_perf import temperature
out=Path('/Users/shifu/code/os/moss/build/rpi3b/pmu')
record={'scope':'single-core repeated 1 MiB copies; temperature sampling halts idle CPU3; not a throughput benchmark','samples':[]}
path=out/f'thermal-stress-{time.time_ns()}.json'
with uart(serial_port(None)) as fd:
    # Nine batches * 4096 MiB = 36 GiB, bounded by a two-minute host watchdog.
    for byte in b'/rpi-perf.elf memcpy 4096 1048576; echo RPI_COMMAND_STATUS=$?\n':
        write_all(fd,bytes([byte]));time.sleep(0.002)
    start=time.monotonic(); next_sample=start; data=bytearray()
    while True:
        if time.monotonic()-start > 120:
            record['status']='timeout'; break
        if time.monotonic()>=next_sample:
            sample=temperature(); sample['elapsed_s']=time.monotonic()-start
            record['samples'].append(sample)
            print(f"{sample['elapsed_s']:.1f}s {sample['millidegrees_c']/1000:.2f}C",flush=True)
            next_sample=time.monotonic()+2 # Two-second thermal cadence, outside accepted latency runs.
            path.write_text(json.dumps(record,indent=2)+'\n')
        if select.select([fd],[],[],0.1)[0]:
            data.extend(os.read(fd,4096))
        lines=data.decode(errors='replace').replace('\r\n','\n').splitlines()
        if 'RPI_COMMAND_STATUS=0' in lines and data.endswith(b'moss$ '):
            record['status']='passed' if 'RPI_PERF_DONE' in lines else 'failed'; break
    record['elapsed_s']=time.monotonic()-start
    record['transcript']=data.decode(errors='replace')
path.write_text(json.dumps(record,indent=2)+'\n')
print(path)
if record['status']!='passed': raise SystemExit(1)
