from argparse import Namespace
from pathlib import Path
import json, sys
sys.path.insert(0, '/Users/shifu/code/os/moss')
from scripts import rpi
from scripts.kernel_validation import Protocol
original_command = rpi.OpenOCD.command
original_prepare = rpi.prepare_image
original_console = rpi.console

def command(self, value):
    return original_command(self, 'adapter speed 1000' if value == 'adapter speed 4000' else value)

def prepare(*args):
    result = original_prepare(*args)
    rpi.run(rpi.tool('fdtput'), '-t', 's', str(result[2]), '/chosen', 'bootargs',
            'console=ttyAMA0,115200 moss.validation=mm.permissions moss.cpus=4 moss.memory=948')
    return result

def console(fd, log, **kwargs):
    kwargs.update(check=False, expect='"completed":8,"selected":8,"failed":0,"reason":"complete"}')
    original_console(fd, log, **kwargs)
    serial = log.read_bytes()
    # Reuse the fail-closed catalog/ready/case/end checks. Four cores and 948 MiB
    # are the firmware-reported topology/RAM used in this board's bootargs.
    state = Protocol("mm.permissions", 4, 948, 0, 0)
    for line in serial.splitlines():
        state.accept(line)
    status, reason = state.outcome("protocol_end", None, serial)
    record = {"status": status, "reason": reason, "hardware": "Raspberry Pi 3B+",
              "ready": state.ready, "cases": [case["assertions"] for case in state.cases],
              "end": state.end, "jtag_khz": 1000}
    (log.parent / "validation-result.json").write_text(json.dumps(record, indent=2) + "\n")
    if status != "passed":
        raise RuntimeError(f"Hardware mm.permissions failed: {reason}")

rpi.OpenOCD.command = command
rpi.prepare_image = prepare
rpi.console = console
base = Path(__file__).resolve().parent
rpi.deploy(Namespace(output=base/'deploy',manifest=base/'moss-artifacts.json',dtb=Path('/Users/shifu/code/os/moss/build/rpi3b/firmware.dtb'),port=None,check=False,timeout=60))
