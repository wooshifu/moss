#define main moss_perf_service_main
#include "/Users/shifu/code/os/moss/src/userspace/moss_process_service.c"
#undef main
int main(int argc, char **argv) {
  unsigned mask = 1U << 2; /* Reserve CPU2 for services in the diagnostic image. */
  if (syscall3(SYS_SCHED_SETAFFINITY, 0, sizeof(mask), (long)&mask)) return 1;
  return moss_perf_service_main(argc, argv);
}
