"""Preserve a failed boot check and independently verify live shell recovery."""

import json
import os
import select
import sys
import time
from pathlib import Path

from scripts.rpi import uart, write_all

root = Path(sys.argv[1])
report = {"original_boot_check": "failed: partial echo and 90 second deadline", "status": "running"}
try:
    with uart("/dev/cu.usbserial-14440") as fd, (root / "input-recovery.log").open("xb", buffering=0) as log:
        def receive(expected):
            data = bytearray()
            # Match the existing scripted console's thirty-second liveness bound.
            deadline = time.monotonic() + 30
            while not (data.endswith(b"moss$ ") and
                       (expected is None or expected in data.replace(b"\r\n", b"\n").splitlines())):
                if time.monotonic() >= deadline:
                    raise TimeoutError("Missing independent marker or next prompt")
                if select.select([fd], [], [], 1)[0]:
                    block = os.read(fd, 4096)
                    if not block:
                        raise ConnectionError("UART disconnected")
                    log.write(block)
                    data.extend(block)
            return data.decode(errors="replace")
        write_all(fd, b"\n")
        report["newline_response"] = receive(None)
        for byte in b"echo MOSS_RETURN_PERF_RECOVERY_OK\n":
            write_all(fd, bytes([byte]))
            # Match the existing diagnostic collector's 500 bytes/s input pacing.
            time.sleep(0.002)
        report["probe_response"] = receive(b"MOSS_RETURN_PERF_RECOVERY_OK")
        report["status"] = "passed"
except Exception as error:
    report["status"], report["error"] = "failed", str(error)
    raise
finally:
    (root / "input-recovery.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
