"""Freeze this experiment only after UART/JTAG collection has finished."""

import hashlib
import json
import shutil
import statistics
import subprocess
import tarfile
from collections import Counter
from pathlib import Path

from scripts.artifacts import Artifacts
from scripts.rpi_perf import CASES

repo = Path('/Users/shifu/code/os/moss')
root = Path('/Volumes/MossBuild/moss/evidence')
destination = repo / 'docs/performance'
destination.mkdir(exist_ok=True)
index_path = root / 'return-perf-file-index.json'
assert not index_path.exists(), 'Frozen experiment already exists; do not overwrite it.'


def read(path):
    return json.loads(path.read_text())


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    return {'path': str(path.relative_to(root)), 'bytes': path.stat().st_size,
            'sha256': sha256(path)}


expected_workloads = read(root / 'return-perf-plan.json')['workloads']
expected_parameters = {name: (iterations, size) for name, iterations, size in CASES if name in expected_workloads}
variants = {}
for label in ['baseline-controlled', 'candidate', 'optimized', 'baseline-rollback']:
    directory = root / ('return-perf-' + label)
    cfg = Artifacts.load(directory / 'moss-artifacts.json')
    item = {'build': cfg.build, 'kernel_sha256': identity(cfg.require('kernel'))['sha256'],
            'initramfs_sha256': identity(cfg.require('initramfs'))['sha256'],
            'probe_sha256': identity(directory / 'rpi-perf.elf')['sha256'],
            'preparation_sha256': identity(directory / 'probe-preparation.json')['sha256'],
            'deployment': read(directory / 'deploy/result.json'), 'rounds': []}
    if item['deployment']['boot_check'] != 'shell_input_passed':
        item['input_recovery'] = read(directory / 'input-recovery.json')
        assert item['input_recovery']['status'] == 'passed'
    rounds = read(directory / 'performance-rounds.json')['rounds']
    assert len(rounds) == 2  # The plan retains two consecutive rounds within each boot.
    for round_record in rounds:
        assert round_record['status'] == 'passed' and len(round_record['measurement_files']) == 1
        path = directory / round_record['measurement_files'][0]
        data = read(path)
        assert data['status'] == 'passed' and data['pmu'] is False
        assert {case['workload'] for case in data['cases']} == set(expected_workloads)
        assert len(data['cases']) == len(expected_workloads)
        assert data['probe_sha256'] == item['probe_sha256']
        assert data['deployment_record']['files']['kernel']['sha256'] == item['kernel_sha256']
        result = {**round_record, 'measurement': identity(path), 'cases': []}
        for case in data['cases']:
            rows = case['samples']
            retained = [row for row in rows if not row['warmup']]
            # Match the unchanged guest and collector protocol: two warmups, seven retained batches.
            assert len(rows) == 9 and len(retained) == 7
            for index, row in enumerate(rows):
                assert row['sample'] == index and row['warmup'] == (index < 2)
                assert row['ns'] > 0 and (row['iterations'], row['bytes']) == expected_parameters[case['workload']]
            values = [row['ns'] / row['iterations'] for row in retained]
            assert (case['min_ns'], case['median_ns'], case['max_ns']) == (
                min(values), statistics.median(values), max(values))
            result['cases'].append({key: case[key] for key in ['workload', 'bytes', 'min_ns', 'median_ns', 'max_ns']} |
                                   {'median_system_switches_per_op': statistics.median(
                                       row['switches'] / row['iterations'] for row in retained)})
        item['rounds'].append(result)
    variants[label] = item
for key in ['initramfs_sha256', 'probe_sha256', 'preparation_sha256']:
    assert len({value[key] for value in variants.values()}) == 1, key
assert variants['baseline-controlled']['kernel_sha256'] == variants['baseline-rollback']['kernel_sha256']

hardware = {}
for label in ['candidate', 'optimized']:
    data = read(root / ('return-perf-' + label + '-release-frame/validation-result.json'))
    assert data['finalized'] and data['status'] == 'passed'
    assert len(data['cases']) == 4 and all(case['status'] == 'passed' for case in data['cases'])
    hardware[label] = data
qemu = {}
for arch in ['arm64', 'x64', 'riscv64']:
    path = root / ('return-perf-optimized-' + arch + '-qemu/results.json')
    data = read(path)
    assert data['finalized'] and not data['not_run']
    assert len(data['guests']) == 3  # Frame, scheduler and IPC are the three selected suites.
    assert all(guest['status'] == 'passed' for guest in data['guests'])
    counts = Counter(case['status'] for guest in data['guests'] for case in guest['cases'])
    assert counts == {'passed': 44}  # Current catalog: 4 frame + 18 scheduler + 22 IPC cases.
    qemu[arch] = {'report': identity(path), 'provenance': data['provenance'], 'case_counts': dict(counts)}

production = read(root / 'return-perf-production/result.json')
assert production['boot_check'] == 'shell_input_passed'
assert production['files']['kernel']['sha256'] == variants['optimized']['kernel_sha256']
detach = read(root / 'return-perf-production-detach.json')
assert detach['shutdown_requested'] is True
source = read(root / 'return-perf-optimized-identity.json')
patch = subprocess.check_output(['git', 'diff', '--binary', source['base_revision'], '--', 'src/kernel/src/kernel_main.cpp'], cwd=repo)
assert hashlib.sha256(patch).hexdigest() == source['patch_sha256']

# Preserve the local orchestration too; it adds no repository policy or runtime interface.
for name in ['run_return_perf.py', 'recover_return_perf_input.py', 'collect_return_perf_evidence.py']:
    shutil.copyfile(Path(__file__).parent / name, root / ('return-perf-local-' + name))
shutil.copyfile(root / 'firmware.dtb', root / 'return-perf-original-firmware.dtb')
# The generator's own stdout can still be open; it is not an experiment input.
files = sorted(path for entry in root.glob('return-perf-*')
               for path in (entry.rglob('*') if entry.is_dir() else [entry])
               if path.is_file() and path.name != 'return-perf-collection-host.log')
index_path.write_text(json.dumps([identity(path) for path in files], indent=2) + '\n')
files.append(index_path)
raw = destination / 'rpi3b-2026-10-18-return-reschedule-evidence.tar.gz'
complete = root / 'p0-return-reschedule-performance-2026-10-18.tar.gz'
assert not raw.exists() and not complete.exists()
text_suffixes = {'.json', '.log', '.txt', '.patch', '.c', '.cpp', '.cppm', '.S', '.md', '.py'}
for archive, include_binaries in [(raw, False), (complete, True)]:
    with tarfile.open(archive, 'w:gz') as output:
        for path in files:
            if include_binaries or path.suffix in text_suffixes:
                output.add(path, arcname=str(path.relative_to(root)), recursive=False)
    with tarfile.open(archive, 'r:gz') as check:
        for member in check:
            contents = check.extractfile(member)
            assert contents is not None
            assert hashlib.file_digest(contents, 'sha256').hexdigest() == sha256(root / member.name)

summary = {
    'schema_version': 1, 'date': '2026-10-18', 'board': 'Raspberry Pi 3 Model B Plus Rev 1.3',
    'adapter': 'J-Link 000050120677', 'jtag_khz': 1000,
    'method': read(root / 'return-perf-plan.json'), 'pairing': read(root / 'return-perf-pairing.json'),
    'actual_boot_order': list(variants), 'variants': variants, 'optimized_source': source,
    'release_frame_hardware': hardware, 'optimized_debug_qemu': qemu,
    'production': production, 'detach': detach,
    'raw_archive': {'path': raw.name, 'bytes': raw.stat().st_size,
                    'sha256': sha256(raw)},
    'complete_local_archive': {'name': complete.name, 'bytes': complete.stat().st_size,
                               'sha256': sha256(complete)},
    'limits': ['Batch means are not single-operation tail latency or PMU measurements.',
               'Each boot contains two rounds; seven retained batches are not independent boots.',
               'CPU frequency/throttling was not observed. No Linux comparison or sustained-load acceptance.',
               'Original candidate boot input failures remain failures despite independent recovery.',
               'The earlier RV64 users.exec timeout and full scheduler ownership remain unresolved.'],
}
target = destination / 'rpi3b-2026-10-18-return-reschedule.json'
target.write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['raw_archive', 'complete_local_archive']}, indent=2))
print(target)
