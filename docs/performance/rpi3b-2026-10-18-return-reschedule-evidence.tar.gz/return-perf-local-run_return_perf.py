"""Local experiment orchestration; the repository collector validates every sample."""

import json
import sys
import time
from pathlib import Path

from scripts.rpi_perf import measure, temperature

output = Path(sys.argv[1])
record = output / "performance-rounds.json"
if record.exists():
    raise FileExistsError(record)
workloads = ["clock", "getpid_raw", "getpid_libc", "yield", "fork_raw", "fork_libc", "exec", "ipc0", "ipc1"]
report = {"mode": "batch means; PMU disabled", "workloads": workloads, "rounds": []}
# The experiment plan calls for two consecutive rounds in the same boot.
for index in range(2):
    item = {"round": index + 1, "started_ns": time.time_ns(), "status": "running"}
    report["rounds"].append(item)
    existing = set(output.glob("measurements-*.json"))
    try:
        item["temperature_before"] = temperature()
        measure("/dev/cu.usbserial-14440", output, workloads, pmu=False)
        item["temperature_after"] = temperature()
        item["status"] = "passed"
    except Exception as error:
        item["status"], item["error"] = "failed", str(error)
        raise
    finally:
        item["finished_ns"] = time.time_ns()
        item["measurement_files"] = sorted(path.name for path in set(output.glob("measurements-*.json")) - existing)
        record.write_text(json.dumps(report, indent=2) + "\n")
