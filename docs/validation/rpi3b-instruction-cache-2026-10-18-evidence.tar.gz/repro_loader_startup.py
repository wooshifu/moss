"""Local Pi Loader constructor/recovery loop; preserve failures verbatim."""

import json
import os
from pathlib import Path
import select
import sys
import time

from scripts.rpi import uart, write_all

root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=False)
cycles = int(sys.argv[2])
report = {'status': 'running', 'requested_cycles': cycles, 'cycles': []}
# Reuse the physical validation runner's per-case liveness budget. It is not
# a performance acceptance threshold and is never extended after a failure.
case_seconds = 30
faults = (b'USER PAGE FAULT', b'USER FAULT:', b'Kernel panic', b'ASSERTION FAILED')

with uart('/dev/cu.usbserial-14440') as fd, (root / 'serial.log').open('xb', buffering=0) as log:
    def send(data):
        # The existing diagnostic input rate keeps serial transmission outside
        # the startup check; this loop diagnoses service faults, not RX speed.
        for byte in data:
            write_all(fd, bytes([byte]))
            time.sleep(0.002)

    def receive(required):
        deadline = time.monotonic() + case_seconds
        raw = bytearray()
        fault_seen = False
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if fault_seen:
                    raise AssertionError('kernel/user fault observed during Loader startup')
                raise TimeoutError(f'missing startup markers: {required!r}')
            if not select.select([fd], [], [], min(remaining, 0.1))[0]:
                continue
            data = os.read(fd, 4096)
            if not data:
                raise ConnectionError('UART disconnected')
            log.write(data)
            raw.extend(data)
            clean = raw.replace(b'\r\n', b'\n')
            if not fault_seen and any(marker in clean for marker in faults):
                fault_seen = True
                # Preserve the rest of the diagnostic and the supervisor's
                # one-second recovery before restoring the host UART settings.
                deadline = min(deadline, time.monotonic() + 2)
            if fault_seen:
                continue
            if b'MOSS_DOMAIN_ERROR' in clean:
                raise AssertionError('Loader termination handle rejected')
            if all(marker in clean for marker in required) and clean.endswith(b'moss$ '):
                return bytes(clean)

    try:
        send(b'\necho MOSS_LOADER_SYNC\n')
        receive([b'\nMOSS_LOADER_SYNC\n'])
        # Fast boot creates the first shell before the Loader exists. Restart
        # only that shell so its replacement inherits the management handles.
        send(b'exit\n')
        receive([b'moss-init: restarting shell', b'built-in shell (ash)'])
        for cycle in range(cycles):
            item = {'cycle': cycle, 'status': 'running'}
            report['cycles'].append(item)
            started = time.monotonic()
            send(b'/moss-domain.elf terminate loader\n')
            clean = receive([b'moss-init: loader service died', b'moss-init: loader service started',
                             b'moss-init: restarting shell', b'built-in shell (ash)'])
            assert clean.count(b'moss-init: loader service died') == 1, 'unexpected extra Loader death'
            assert clean.count(b'moss-init: loader service started') == 1, 'unexpected extra Loader start'
            # A separate command proves that the replacement shell is live.
            marker = f'MOSS_LOADER_CYCLE_{cycle}'.encode()
            send(b'echo ' + marker + b'\n')
            receive([b'\n' + marker + b'\n'])
            item.update(status='passed', elapsed_seconds=time.monotonic() - started)
            print(json.dumps(item), flush=True)
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        if report['cycles']:
            report['cycles'][-1]['status'] = 'failed'
        raise
    finally:
        (root / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
