"""Freeze the completed instruction-publication experiment without changing prior evidence."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import tarfile

from scripts.artifacts import Artifacts
from scripts.rpi_perf import CASES

repo = Path('/Users/shifu/code/os/moss')
root = Path('/Volumes/MossBuild/moss/evidence/loader-startup-diagnosis')
destination = repo / 'docs/validation'
stem = 'rpi3b-instruction-cache-2026-10-18'
report_path = destination / (stem + '.json')
assert not report_path.exists(), 'Do not overwrite a frozen experiment.'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


hardware = {}
for label in ['red', 'green']:
    record = read(root / f'pi-regression-{label}/validation-result.json')
    assert record['finalized'] and record['catalog_version'] == 13
    hardware[label] = record
assert hardware['red']['status'] == 'failed'
assert hardware['green']['status'] == 'passed'
assert hardware['red']['provenance']['fixture_sha256'] == hardware['green']['provenance']['fixture_sha256']
assert hardware['red']['provenance']['source_status'] == 'unrecorded'
assert hardware['green']['provenance']['source_status'] == 'recorded'

qemu = {}
for arch, expected in [('arm64', {'passed': 88}), ('x64', {'passed': 88}),
                       ('riscv64', {'passed': 82, 'error': 1, 'not_run': 5})]:
    path = root / f'qemu-green-{arch}/results.json'
    record = read(path)
    assert record['finalized'] and record['catalog_version'] == 13
    counts = dict(Counter(c['status'] for g in record['guests'] for c in g['cases']))
    assert counts == expected, counts
    qemu[arch] = {'report': identity(path), 'case_counts': counts, 'provenance': record['provenance']}

plan = read(root / 'performance-plan.json')
parameters = {name: (iterations, size) for name, iterations, size in CASES if name in plan['workloads']}
performance = {}
for variant in plan['boots']:
    directory = root / variant
    cfg = Artifacts.load(directory / 'moss-artifacts.json')
    rounds = read(directory / 'performance-rounds.json')['rounds']
    assert len(rounds) == plan['rounds_per_boot']
    item = {'kernel': identity(cfg.require('kernel')), 'initramfs': identity(cfg.require('initramfs')),
            'probe': identity(directory / 'rpi-perf.elf'), 'build': cfg.build, 'rounds': []}
    assert item['initramfs']['sha256'] == plan['archive_sha256']
    for row in rounds:
        assert row['status'] == 'passed' and len(row['measurement_files']) == 1
        path = directory / row['measurement_files'][0]
        data = read(path)
        assert data['status'] == 'passed' and data['pmu'] is False
        assert {c['workload'] for c in data['cases']} == set(plan['workloads'])
        if data['deployment_record']['boot_check'] != 'shell_input_passed':
            # Recovery is separate evidence; retain the original failed boot verdict.
            item['input_recovery'] = read(directory / 'input-recovery.json')
            assert item['input_recovery']['status'] == 'passed'
        assert data['deployment_record']['files']['kernel']['sha256'] == item['kernel']['sha256']
        assert data['probe_sha256'] == item['probe']['sha256']
        for case in data['cases']:
            samples = case['samples']
            # This is the probe's fixed protocol, never a percentile sample count.
            assert len(samples) == 9 and sum(not s['warmup'] for s in samples) == 7
            assert all((s['iterations'], s['bytes']) == parameters[case['workload']] for s in samples)
            values = [s['ns'] / s['iterations'] for s in samples if not s['warmup']]
            assert case['median_ns'] == statistics.median(values)
        item['rounds'].append({'record': row, 'measurement': identity(path),
                               'cases': [{k: case[k] for k in ['workload', 'bytes', 'median_ns', 'min_ns', 'max_ns']}
                                         for case in data['cases']]})
    performance[variant] = item
assert len({v['probe']['sha256'] for v in performance.values()}) == 1

loader = read(root / 'cache-fix-loop-01/result.json')
assert loader['status'] == 'passed' and len(loader['cycles']) == loader['requested_cycles'] == 50
production = read(root / 'production-restore/result.json')
detach = read(root / 'production-detach.json')
assert production['boot_check'] == 'shell_input_passed'
assert production['files']['kernel']['sha256'] == performance['perf-fixed']['kernel']['sha256']
assert detach['all_cpus_running'] and detach['shutdown_requested']

source_paths = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=repo).decode().splitlines()
source_paths += ['docs/rpi3b-instruction-cache-validation.md']
for name in source_paths:
    target = root / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
(root / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=repo))
for name in ['repro_loader_startup.py', 'run_instruction_perf.py', 'recover_instruction_perf_input.py',
             'freeze_instruction_evidence.py']:
    shutil.copyfile(Path('/Volumes/MossBuild/moss/tmp') / name, root / name)

files = sorted(p for p in root.rglob('*') if p.is_file())
index = {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files}
index_path = root / 'file-index.json'
assert not index_path.exists()
index_path.write_text(json.dumps(index, indent=2) + '\n')
files.append(index_path)
text_suffixes = {'.txt', '.log', '.json', '.py', '.patch', '.md', '.cpp', '.cppm', '.S', '.c', '.h', '.hpp', '.gdb'}
full_archive = root.parent / (stem + '-full.tar.gz')
text_archive = Path('/Volumes/MossBuild/moss/tmp') / (stem + '-evidence.tar.gz')
for archive, paths in [(full_archive, files), (text_archive, [p for p in files if p.suffix in text_suffixes])]:
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as tar:
        for path in paths:
            tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
shutil.copyfile(text_archive, destination / text_archive.name)
report = {
    'date': '2026-10-18', 'base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'scope': 'ARM64 executable-page publication; demand fault and native domain construction',
    'hardware': hardware, 'loader_loop': loader, 'qemu': qemu, 'performance_plan': plan,
    'performance': performance, 'production_restore': production, 'detach': detach,
    'first_failures': ['current-pi-loop', 'current-pi-loop-02', 'jtag-fault-01', 'pi-regression-red',
                       'build-cache-regression-01.log', 'perf-baseline/readback-failure.json',
                       'perf-baseline-02/deploy/result.json', 'perf-baseline-02/performance-rounds-attempt-01.json',
                       'qemu-green-riscv64/mm.transactions/diagnostics', 'production-detach-attempt-01.json'],
    'limits': ['No Linux baseline, single-operation tails, long-duration or arbitrary-platform claim',
               'Historical and current pressure-release QEMU timeouts remain open',
               'Red binary provenance sidecar was absent and remains unrecorded'],
    'full_evidence': identity(full_archive), 'text_evidence': identity(destination / text_archive.name),
    'file_index': identity(index_path),
}
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(report_path), 'full_evidence': report['full_evidence'],
                  'text_evidence': report['text_evidence']}, indent=2))
