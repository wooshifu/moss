"""Freeze shell-check evidence after both PTY and live Pi checks have ended."""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
repo = Path('/Users/shifu/code/os/moss')
destination = repo / 'docs/validation'
stem = 'rpi3b-shell-check-2026-10-18'
report_path = destination / (stem + '.json')
assert not report_path.exists()


def read(name):
    return json.loads((root / name).read_text())


def identity(path):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}


red = ET.parse(root / 'host-red.xml').getroot().find('testsuite')
green = ET.parse(root / 'host-green.xml').getroot().find('testsuite')
assert red is not None and green is not None
assert (red.get('tests'), red.get('failures'), red.get('errors')) == ('8', '3', '0')
assert (green.get('tests'), green.get('failures'), green.get('errors'), green.get('skipped')) == ('261', '0', '0', '1')
green_cases = [case for case in green.findall('testcase') if case.get('name', '').startswith('test_boot_check_requires_command_output[')]
assert len(green_cases) == 8 and all(len(case) == 0 for case in green_cases)
red_cases = {case.get('name'): 'failed' if case.find('failure') is not None else 'passed' for case in red.findall('testcase')}
assert set(red_cases) == {case.get('name') for case in green_cases}

live = read('pi-check.json')
replay = read('original-replay.json')
original = read('original-false-timeout-result.json')
assert original['boot_check'] == 'failed' and live['status'] == 'passed'
assert replay['results'][0]['timeout'] and replay['results'][0]['returncode'] == 1
assert not replay['results'][1]['timeout'] and replay['results'][1]['returncode'] == 0
assert live['runner_sha256'] == replay['results'][1]['source_sha256'] == identity(repo / 'scripts/rpi.py')['sha256']
assert read('running-image-deployment.json') == live['deployment']
assert live['deployment']['boot_check'] == 'shell_input_passed'
assert replay['response_sha256'] == identity(root / 'original-response.log')['sha256']
serial = (root / 'pi-check-serial.log').read_bytes().replace(b'\r\n', b'\n')
result_end = serial.index(b'\nMOSS_RPI_INPUT_OK\n') + len(b'\nMOSS_RPI_INPUT_OK\n')
assert b'moss$ ' in serial[result_end:]
assert all(check['exit_code'] == 0 for check in read('checks-final.json'))
connection = read('final-connection-state.json')
assert connection['uart_lsof'] == {'exit_code': 1, 'stdout': '', 'stderr': ''}
assert all(state == 'closed' for state in connection['debug_ports'].values())

source_paths = ['scripts/rpi.py', 'scripts/tests/test_rpi.py', 'docs/rpi3b.md', 'docs/kernel-roadmap.md',
                'todo.md', 'moss-todo.md', 'docs/rpi3b-shell-check-validation.md']
tracked = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=repo).decode().splitlines()
assert set(tracked) == set(source_paths) - {'docs/rpi3b-shell-check-validation.md'}
for name in source_paths:
    target = root / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
(root / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=repo))
files = sorted(path for path in root.rglob('*') if path.is_file() and not path.is_symlink())
index = {str(path.relative_to(root)): {key: value for key, value in identity(path).items() if key != 'path'} for path in files}
index_path = root / 'file-index.json'
assert not index_path.exists()
index_path.write_text(json.dumps(index, indent=2) + '\n')
files.append(index_path)
full_archive = root.parent / (stem + '-full.tar.gz')
text_archive = Path('/Volumes/MossBuild/moss/tmp') / (stem + '-evidence.tar.gz')
text_suffixes = {'.txt', '.log', '.json', '.py', '.patch', '.md', '.xml'}
for archive, selected in [(full_archive, files), (text_archive, [p for p in files if p.suffix in text_suffixes])]:
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as tar:
        for path in selected:
            tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
shutil.copyfile(text_archive, destination / text_archive.name)
report = {
    'date': '2026-10-18', 'base_revision': read('plan.json')['base_revision'],
    'scope': 'Host console shell-input completion after a fresh probe',
    'source': {name: identity(repo / name) for name in source_paths}, 'patch': identity(root / 'source.patch'),
    'host': {'red_cases': red_cases, 'green_total': dict(green.attrib), 'green_directed_cases': len(green_cases)},
    'original_failed_deployment': original, 'exact_response_replay': replay, 'live_pi': live,
    'final_connection_state': connection, 'checks': read('checks-final.json'),
    'limits': ['The live exchange used an already running, previously readback-verified image',
               'Startup asynchronous bytes were verified by PTY replay; the new live exchange had no such startup log',
               'No kernel rebuild, QEMU rerun, upload or performance claim; prior kernel failures remain open'],
    'full_evidence': identity(full_archive), 'text_evidence': identity(destination / text_archive.name),
    'file_index': identity(index_path),
}
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(report_path), 'full_evidence': report['full_evidence'],
                  'text_evidence': report['text_evidence']}, indent=2))
