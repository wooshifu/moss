"""Check the already deployed production Pi without reset or another reader."""

import hashlib
import json
from pathlib import Path
import time

from scripts import rpi

root = Path(__file__).resolve().parent
record_path = root / 'pi-check.json'
assert not record_path.exists()
deployment = json.loads((root / 'running-image-deployment.json').read_text())
assert deployment['boot_check'] == 'shell_input_passed'
record = {
    'status': 'running',
    'board': 'Raspberry Pi 3 Model B Plus Rev 1.3',
    'port': '/dev/cu.usbserial-14440',
    'deployment': deployment,
    'runner_sha256': hashlib.sha256(Path(rpi.__file__).read_bytes()).hexdigest(),
    # This bounds a new shell exchange on the running board; it is not a latency budget.
    'timeout_seconds': 30,
}
started = time.monotonic()
try:
    with rpi.uart(record['port']) as fd:
        rpi.console(fd, root / 'pi-check-serial.log', timeout=record['timeout_seconds'], send='', expect=None, check=True)
    record['status'] = 'passed'
except Exception as error:
    record['status'] = 'failed'
    record['error'] = repr(error)
    raise
finally:
    record['elapsed_seconds'] = time.monotonic() - started
    record_path.write_text(json.dumps(record, indent=2) + '\n')
