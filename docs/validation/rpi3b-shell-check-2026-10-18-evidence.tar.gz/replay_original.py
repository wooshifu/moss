"""Replay the actual failed Pi response through the old and fixed POSIX consoles."""

import hashlib
import json
import os
from pathlib import Path
import pty
import select
import subprocess
import sys

from scripts import rpi

root = Path(__file__).resolve().parent
path = root / 'original-replay.json'
assert not path.exists()
serial = (root / 'original-false-timeout-serial.log').read_bytes()
response = serial.split(rpi.PROMPT, 1)[1]
normalized = response.replace(b'\r\n', b'\n')
assert rpi.PROBE_RESULT in normalized and not normalized.endswith(rpi.PROMPT)
assert rpi.PROMPT in normalized.split(rpi.PROBE_RESULT, 1)[1]
(root / 'original-response.log').write_bytes(response)
program = '''
import importlib.util
from pathlib import Path
import sys
spec = importlib.util.spec_from_file_location('checked_rpi', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
with module.uart(sys.argv[2]) as fd:
    module.console(fd, Path(sys.argv[3]), timeout=1, send=None, expect=None, check=True)
'''
results = []
for label, source in [('old', root / 'baseline/rpi.py'), ('fixed', Path(rpi.__file__))]:
    master, slave = pty.openpty()
    process = subprocess.Popen([sys.executable, '-c', program, str(source), os.ttyname(slave),
                                str(root / f'replay-{label}-serial.log')],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        # Host scheduling gets three seconds; console's invalid-response deadline stays one second.
        assert select.select([process.stderr], [], [], 3)[0]
        process.stderr.readline()
        os.write(master, rpi.PROMPT)
        assert select.select([master], [], [], 3)[0]
        assert os.read(master, len(rpi.PROBE_COMMAND)) == rpi.PROBE_COMMAND
        assert select.select([process.stdout], [], [], 3)[0]
        assert process.stdout.read(len(rpi.PROMPT)) == rpi.PROMPT
        os.write(master, response)
        # Five seconds covers the one-second check and interpreter teardown.
        stdout, stderr = process.communicate(timeout=5)
        (root / f'replay-{label}-stdout.log').write_bytes(stdout)
        (root / f'replay-{label}-stderr.log').write_bytes(stderr)
        results.append({'variant': label, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                        'returncode': process.returncode, 'timeout': b'Expected shell response was not received' in stderr})
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        os.close(master)
        os.close(slave)
path.write_text(json.dumps({'response_sha256': hashlib.sha256(response).hexdigest(), 'results': results}, indent=2) + '\n')
assert results[0]['returncode'] != 0 and results[0]['timeout']
assert results[1]['returncode'] == 0 and not results[1]['timeout']
assert results[1]['source_sha256'] == json.loads((root / 'pi-check.json').read_text())['runner_sha256']
print('Exact original response: old console timed out; fixed console passed.')
