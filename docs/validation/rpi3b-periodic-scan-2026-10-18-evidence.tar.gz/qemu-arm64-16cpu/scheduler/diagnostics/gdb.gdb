
set pagination off
set confirm off
set may-call-functions off
set print elements 16
set print repeats 2
set print max-depth 3
set remotetimeout 2
python
import gdb, json
config = json.loads('{"socket": "/Volumes/MossBuild/moss/tmp/moss-qmp-h3bit1aj/gdb.sock", "symbols": "/Volumes/MossBuild/moss/evidence/scheduler-global-2026-10-18/qemu-arm64-16cpu/inputs/validation_debug_symbols/moss.test.symbols.elf", "offset": 1075838976, "cpus": 16, "minimal": false, "output": "/Volumes/MossBuild/moss/evidence/scheduler-global-2026-10-18/qemu-arm64-16cpu/scheduler/diagnostics/gdb.json"}')
snapshot = {"cpus": [], "tasks": [], "errors": []}
def run(command):
    try:
        output = gdb.execute(command, to_string=True)
        print(command + "\n" + output, flush=True)
        return output
    except gdb.error as error:
        snapshot["errors"].append(command + ": " + str(error))
        print("unavailable: " + command + ": " + str(error), flush=True)
        return None
gdb.execute("target remote " + config["socket"])
gdb.execute("symbol-file " + ("-readnever " if config["minimal"] else "")
            + "-o " + hex(config["offset"]) + " " + json.dumps(config["symbols"]))
run("info threads")
for thread in gdb.selected_inferior().threads():
    thread.switch()
    snapshot["cpus"].append({"thread": thread.num,
        "registers": run("info registers"), "backtrace": run("bt 12"),
        "instructions": run("x/8i $pc"), "stack": run("x/16gx $sp")})
# Use this ELF's DWARF field layout, not hard-coded offsets or guest function calls.
try:
    tasks = gdb.parse_and_eval("'_ZN4moss6kernel7processW4mossW7process12CfsScheduler22current_running_tasks_E'")
    slots = tasks["data_"] if int(tasks["data_"]) else tasks["boot_buf_"]
    for cpu in range(config["cpus"]):
        pointer = slots[cpu]["value"]
        task = {"vcpu": cpu, "address": str(pointer)}
        if int(pointer):
            value = pointer.dereference()
            for field in ("tid", "owner_pid", "cpu", "state", "sleep_handoff", "wait_queue"):
                task[field] = str(value[field])
        snapshot["tasks"].append(task)
except gdb.error as error:
    snapshot["errors"].append("task state unavailable: " + str(error))
run("p '_ZN4moss6kernel7processW4mossW7process11g_schedulerE'")
with open(config["output"], "w") as stream:
    json.dump(snapshot, stream, indent=2)
print("MOSS_DIAGNOSTICS_DONE", flush=True)
gdb.execute("disconnect")
end
quit
