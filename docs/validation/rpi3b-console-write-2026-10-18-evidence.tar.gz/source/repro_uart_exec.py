"""Local Pi reproducer: a shell line arriving during CPU0 fork/exec/wait."""

import json
import os
import select
import sys
import time
from pathlib import Path

from scripts.rpi import uart, write_all

root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=False)
report = {"status": "running", "cases": []}
workload = sys.argv[2] if len(sys.argv) > 2 else 'exec'
iterations = int(sys.argv[3]) if len(sys.argv) > 3 else 4
report['workload'] = workload
report['iterations'] = iterations
with uart('/dev/cu.usbserial-14440') as fd, (root / 'serial.log').open('xb', buffering=0) as raw:
    def read_chunk(deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('independent marker and next prompt missing')
        if not select.select([fd], [], [], min(remaining, 0.1))[0]:
            return b''
        data = os.read(fd, 4096)
        if not data:
            raise ConnectionError('UART disconnected')
        raw.write(data)
        return data

    try:
        for index in range(3):
            marker = f'MOSS_UART_EXEC_{index:02d}'.encode()
            item = {'name': marker.decode(), 'status': 'running'}
            report['cases'].append(item)
            command = f'/rpi-perf.elf {workload} {iterations} 1; echo MOSS_UART_LOAD_STATUS=$?\n'
            write_all(fd, command.encode())
            data = bytearray()
            # The bounded 36 child lifecycles normally finish well below five seconds.
            deadline = time.monotonic() + 5
            while b'RPI_PERF {' not in data:
                data.extend(read_chunk(deadline))
            item['received_before_input'] = len(data)
            write_all(fd, b'echo ' + marker + b'\n')
            while True:
                normalized = data.replace(b'\r\n', b'\n')
                if marker in normalized.splitlines() and normalized.endswith(b'moss$ '):
                    break
                data.extend(read_chunk(deadline))
            lines = normalized.splitlines()
            assert b'MOSS_UART_LOAD_STATUS=0' in lines, 'native probe did not exit successfully'
            assert sum(line.startswith(b'RPI_PERF {') for line in lines) == 9, 'incomplete native probe'
            assert b'RPI_PERF_DONE' in lines, 'missing native probe end'
            item['status'] = 'passed'
        report['status'] = 'passed'
    except Exception as error:
        report['status'], report['error'] = 'failed', str(error)
        if report['cases']:
            report['cases'][-1]['status'] = 'failed'
        print(repr(bytes(data[-800:])), flush=True)
        raise
    finally:
        (root / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2), flush=True)
