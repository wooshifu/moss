"""Local Pi reproducer: full-speed shell input during a bounded UART write."""

import json
import os
import select
import sys
import time
from pathlib import Path

from scripts.rpi import uart, write_all

root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=False)
report = {"status": "running", "cases": [], "port": "/dev/cu.usbserial-14440"}

with uart(report["port"]) as fd, (root / "serial.log").open("xb", buffering=0) as raw:
    def read_chunk(deadline):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("independent marker and next prompt missing")
        if not select.select([fd], [], [], min(remaining, 0.1))[0]:
            return b""
        data = os.read(fd, 4096)
        if not data:
            raise ConnectionError("UART disconnected")
        raw.write(data)
        return data

    def receive(marker, data=None):
        data = bytearray() if data is None else data
        # Five seconds is a liveness check for this bounded ~0.36-second write.
        deadline = time.monotonic() + 5
        while True:
            normalized = data.replace(b"\r\n", b"\n")
            if marker in normalized.splitlines() and normalized.endswith(b"moss$ "):
                return data
            try:
                data.extend(read_chunk(deadline))
            except TimeoutError:
                print(repr(bytes(data[-512:])), flush=True)
                raise

    try:
        # A paced synchronization command avoids inheriting an incomplete line.
        for byte in b"\necho MOSS_UART_SYNC\n":
            write_all(fd, bytes([byte]))
            time.sleep(0.002)
        receive(b"MOSS_UART_SYNC")
        for index in range(10):
            marker = f"MOSS_UART_IDLE_{index:02d}".encode()
            item = {"name": marker.decode(), "status": "running"}
            report["cases"].append(item)
            write_all(fd, b"echo " + marker + b"\n")
            receive(marker)
            item["status"] = "passed"
        for index in range(3):
            marker = f"MOSS_UART_DUPLEX_{index:02d}".encode()
            item = {"name": marker.decode(), "status": "running"}
            report["cases"].append(item)
            write_all(fd, b"printf '%4096s\\n' x\n")
            data = bytearray()
            deadline = time.monotonic() + 5
            # Send while the long field is physically on the wire, before prompt.
            while data.count(b" ") < 128:
                data.extend(read_chunk(deadline))
            item["received_before_input"] = len(data)
            write_all(fd, b"echo " + marker + b"\n")
            receive(marker, data)
            item["status"] = "passed"
        report["status"] = "passed"
    except Exception as error:
        report["status"] = "failed"
        report["error"] = str(error)
        if report["cases"]:
            report["cases"][-1]["status"] = "failed"
        raise
    finally:
        (root / "result.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report, indent=2), flush=True)
