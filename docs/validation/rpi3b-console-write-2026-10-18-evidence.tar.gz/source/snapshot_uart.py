"""Local MMIO observation outside the serial experiment; restore CPU0 afterward."""

import json
import sys
from pathlib import Path

from scripts.rpi import OpenOCD

path = Path(sys.argv[1])
assert not path.exists(), path
record = {'reads': {}}
with OpenOCD() as oc:
    record['targets_before'] = oc.command('targets')
    oc.command('targets bcm2837.cpu0')
    oc.command('halt')
    try:
        for name, address in [('RSR', 0x3f201004), ('FR', 0x3f201018), ('IMSC', 0x3f201038), ('RIS', 0x3f20103c), ('MIS', 0x3f201040)]:
            record['reads'][name] = oc.command(f'mdw phys {address:#x} 1')
        if len(sys.argv) > 2 and sys.argv[2] == 'clear':
            record['clear'] = oc.command('mww phys 0x3f201004 0')
            record['RSR_after_clear'] = oc.command('mdw phys 0x3f201004 1')
    finally:
        oc.command('resume')
        record['targets_after'] = oc.command('targets')
        path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key not in ('targets_before', 'targets_after')}, indent=2), flush=True)
